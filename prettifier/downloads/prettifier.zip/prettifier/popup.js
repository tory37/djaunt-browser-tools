import { beautifyJson, diffJson, jsonDiffReport, summarizeJsonDiff } from './json-tool.js';
import {
  beautifyMarkdown, diffMarkdown, markdownDiffReport, summarizeMarkdownDiff,
} from './markdown-tool.js';
import { HEADING_ID_PREFIX, renderMarkdown, slugify } from './markdown-render.js';
import { addParam, buildUrl, parseUrl, paramsFromUrl, removeParam } from './url-tool.js';

const api = globalThis.browser ?? globalThis.chrome;

const SAVE_DEBOUNCE_MS = 250;
const STORAGE_KEY = 'prettifier-state';

const DEFAULT_STATE = {
  tab: 'beautify',
  format: 'json',
  indent: 2,
  beautifyInput: '',
  compareA: '',
  compareB: '',
  url: '',
  appliedUrl: '',
};

let state = { ...DEFAULT_STATE };
let saveTimer = null;

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

const els = {
  beautifyInput: $('#beautify-input'),
  beautifyOutput: $('#beautify-output'),
  beautifyError: $('#beautify-error'),
  beautifyCopy: $('#beautify-copy'),
  beautifyDownload: $('#beautify-download'),
  beautifySplit: $('#beautify-split'),
  beautifyInputLabel: $('#beautify-input-label'),
  beautifyResultLabel: $('#beautify-result-label'),
  jsonResultActions: $('#json-result-actions'),
  mdEditorActions: $('#md-editor-actions'),
  mdPreviewActions: $('#md-preview-actions'),
  mdTidy: $('#md-tidy'),
  mdCopy: $('#md-copy'),
  mdDownload: $('#md-download'),
  mdCopyHtml: $('#md-copy-html'),
  mdPreview: $('#md-preview'),
  indentGroup: $('#indent-group'),
  compareA: $('#compare-a'),
  compareB: $('#compare-b'),
  compareSwap: $('#compare-swap'),
  compareError: $('#compare-error'),
  compareDownload: $('#compare-download'),
  diffList: $('#diff-list'),
  diffEmpty: $('#diff-empty'),
  diffSummary: $('#diff-summary'),
  status: $('#status'),
  formatGroup: $('#format-group'),
  urlInput: $('#url-input'),
  urlError: $('#url-error'),
  urlApply: $('#url-apply'),
  urlStale: $('#url-stale'),
  urlParamsField: $('#url-params-field'),
  urlParamsList: $('#url-params-list'),
  urlParamsEmpty: $('#url-params-empty'),
  urlAddParam: $('#url-add-param'),
  urlOriginal: $('#url-original'),
  urlModified: $('#url-modified'),
  urlCopyOriginal: $('#url-copy-original'),
  urlCopyModified: $('#url-copy-modified'),
  urlParamTemplate: $('#urlParamTemplate'),
};

let lastReport = '';
let urlParams = [];
let urlParsed = null;

function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => api.storage.local.set({ [STORAGE_KEY]: state }), SAVE_DEBOUNCE_MS);
}

function setStatus(message, isError = false) {
  els.status.textContent = message;
  els.status.classList.toggle('error', isError);
}

// ---- tabs ----

function activateTab(tab) {
  state.tab = tab;
  $$('.dj-seg[role="tab"]').forEach((btn) => {
    btn.setAttribute('aria-selected', String(btn.dataset.tab === tab));
  });
  $('#panel-beautify').hidden = tab !== 'beautify';
  $('#panel-compare').hidden = tab !== 'compare';
  $('#panel-url').hidden = tab !== 'url';
  els.formatGroup.hidden = tab === 'url';
  applyBeautifyLayout();
  save();
}

$$('.dj-seg[role="tab"]').forEach((btn) => {
  btn.addEventListener('click', () => activateTab(btn.dataset.tab));
});

// ---- format ----

function activateFormat(format) {
  state.format = format;
  $$('#format-group .dj-seg').forEach((btn) => {
    btn.setAttribute('aria-checked', String(btn.dataset.format === format));
  });
  applyBeautifyLayout();
  runBeautify();
  runCompare();
  save();
}

$$('#format-group .dj-seg').forEach((btn) => {
  btn.addEventListener('click', () => activateFormat(btn.dataset.format));
});

// ---- indent ----

function activateIndent(indent) {
  state.indent = indent;
  $$('#indent-group .dj-seg').forEach((btn) => {
    btn.setAttribute('aria-checked', String(Number(btn.dataset.indent) === indent));
  });
  runBeautify();
  save();
}

$$('#indent-group .dj-seg').forEach((btn) => {
  btn.addEventListener('click', () => activateIndent(Number(btn.dataset.indent)));
});

// ---- beautify ----

// JSON is a paste → result flow; Markdown is a two-panel editor with a live rendered
// preview, so the panel's labels, buttons and (in the popup's case) width follow the format.
function applyBeautifyLayout() {
  const isMarkdown = state.format === 'markdown';
  els.beautifySplit.classList.toggle('is-markdown', isMarkdown);
  document.body.classList.toggle('wide', isMarkdown && state.tab === 'beautify');
  els.beautifyInputLabel.textContent = isMarkdown ? 'Markdown' : 'Input';
  els.beautifyResultLabel.textContent = isMarkdown ? 'Preview' : 'Result';
  els.beautifyInput.placeholder = isMarkdown ? 'Paste or type Markdown here' : 'Paste JSON or Markdown here';
  els.indentGroup.hidden = isMarkdown;
  els.mdEditorActions.hidden = !isMarkdown;
  els.mdPreviewActions.hidden = !isMarkdown;
  els.jsonResultActions.hidden = isMarkdown;
  els.beautifyOutput.hidden = isMarkdown;
  els.mdPreview.hidden = !isMarkdown;
}

function renderPreview(text) {
  // Swapping innerHTML resets scrollTop, which would snap the preview to the top on every
  // keystroke — carry it across.
  const top = els.mdPreview.scrollTop;
  els.mdPreview.innerHTML = text.trim() ? renderMarkdown(text) : '';
  els.mdPreview.scrollTop = top;
}

function runBeautify() {
  const text = els.beautifyInput.value;
  if (state.format === 'markdown') {
    els.beautifyError.hidden = true;
    renderPreview(text);
    return;
  }
  if (!text.trim()) {
    els.beautifyOutput.value = '';
    els.beautifyError.hidden = true;
    return;
  }
  try {
    els.beautifyOutput.value = beautifyJson(text, state.indent);
    els.beautifyError.hidden = true;
  } catch (error) {
    els.beautifyOutput.value = '';
    els.beautifyError.textContent = error.message;
    els.beautifyError.hidden = false;
  }
}

els.beautifyInput.addEventListener('input', () => {
  state.beautifyInput = els.beautifyInput.value;
  runBeautify();
  save();
});

// Keep the preview roughly aligned with wherever the editor is scrolled to.
els.beautifyInput.addEventListener('scroll', () => {
  if (state.format !== 'markdown') return;
  const editor = els.beautifyInput;
  const preview = els.mdPreview;
  const editorRange = editor.scrollHeight - editor.clientHeight;
  const previewRange = preview.scrollHeight - preview.clientHeight;
  if (editorRange <= 0 || previewRange <= 0) return;
  preview.scrollTop = (editor.scrollTop / editorRange) * previewRange;
});

// In-page links (#some-heading) scroll the preview instead of navigating the popup.
els.mdPreview.addEventListener('click', (event) => {
  const link = event.target.closest('a[href^="#"]');
  if (!link) return;
  event.preventDefault();
  let fragment = link.getAttribute('href').slice(1);
  try { fragment = decodeURIComponent(fragment); } catch { /* keep it raw */ }
  const id = HEADING_ID_PREFIX + slugify(fragment);
  const target = Array.from(els.mdPreview.querySelectorAll('[id]')).find((el) => el.id === id);
  if (!target) return;
  els.mdPreview.scrollTop += target.getBoundingClientRect().top - els.mdPreview.getBoundingClientRect().top;
});

els.beautifyCopy.addEventListener('click', async () => {
  if (!els.beautifyOutput.value) return;
  await navigator.clipboard.writeText(els.beautifyOutput.value);
  setStatus('Copied beautified output to the clipboard.');
});

els.mdCopy.addEventListener('click', async () => {
  if (!els.beautifyInput.value) return;
  await navigator.clipboard.writeText(els.beautifyInput.value);
  setStatus('Copied the Markdown to the clipboard.');
});

els.mdCopyHtml.addEventListener('click', async () => {
  const html = els.mdPreview.innerHTML;
  if (!html) return;
  const text = els.mdPreview.innerText;
  if (globalThis.ClipboardItem && navigator.clipboard.write) {
    await navigator.clipboard.write([new ClipboardItem({
      'text/html': new Blob([html], { type: 'text/html' }),
      'text/plain': new Blob([text], { type: 'text/plain' }),
    })]);
    setStatus('Copied the rendered document — paste it as formatted text.');
  } else {
    await navigator.clipboard.writeText(html);
    setStatus('Copied the rendered HTML to the clipboard.');
  }
});

// Rewrites the editor in place. execCommand keeps the edit on the textarea's undo stack
// (assigning .value would wipe it); the assignment is only the fallback.
els.mdTidy.addEventListener('click', () => {
  const input = els.beautifyInput;
  if (!input.value.trim()) return;
  const tidy = beautifyMarkdown(input.value);
  if (tidy === input.value) {
    setStatus('Already tidy.');
    return;
  }
  input.focus();
  input.select();
  if (!document.execCommand('insertText', false, tidy)) {
    input.value = tidy;
    input.dispatchEvent(new Event('input'));
  }
  setStatus('Tidied the Markdown — Ctrl+Z undoes it.');
});

function downloadText(filename, text) {
  const blob = new Blob([text], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

els.beautifyDownload.addEventListener('click', () => {
  if (!els.beautifyOutput.value) return;
  downloadText('pretty.json', els.beautifyOutput.value);
});

els.mdDownload.addEventListener('click', () => {
  if (!els.beautifyInput.value) return;
  downloadText('document.md', els.beautifyInput.value);
});

// ---- compare ----

function renderJsonDiff(a, b) {
  const changes = diffJson(a, b);
  const summary = summarizeJsonDiff(changes);
  els.diffList.replaceChildren();
  for (const change of changes) {
    const row = document.createElement('div');
    row.className = `diff-entry ${change.kind === 'added' ? 'added' : change.kind === 'removed' ? 'removed' : 'changed'}`;
    const path = `<span class="diff-path">${change.path}</span>`;
    if (change.kind === 'added') row.innerHTML = `+ ${path} = ${JSON.stringify(change.after)}`;
    else if (change.kind === 'removed') row.innerHTML = `− ${path} = ${JSON.stringify(change.before)}`;
    else if (change.kind === 'type-changed') {
      row.innerHTML = `~ ${path}: ${change.beforeType} <del>${JSON.stringify(change.before)}</del> <ins>${JSON.stringify(change.after)}</ins> (${change.afterType})`;
    } else {
      row.innerHTML = `~ ${path}: <del>${JSON.stringify(change.before)}</del> <ins>${JSON.stringify(change.after)}</ins>`;
    }
    els.diffList.append(row);
  }
  return { changes, summary, report: jsonDiffReport(changes) };
}

function renderWords(words) {
  return words.map((op) => {
    if (op.type === 'equal') return op.a;
    if (op.type === 'remove') return `<del>${op.a}</del>`;
    return `<ins>${op.b}</ins>`;
  }).join(' ');
}

function describeBlock(block) {
  if (block.type === 'heading') return `${'#'.repeat(block.level)} ${block.text}`;
  if (block.type === 'list') return block.items.join(', ');
  if (block.type === 'code') return `[code block${block.lang ? ` · ${block.lang}` : ''}]`;
  if (block.type === 'hr') return '---';
  return block.text;
}

function renderMarkdownDiff(a, b) {
  const sections = diffMarkdown(a, b);
  const summary = summarizeMarkdownDiff(sections);
  els.diffList.replaceChildren();
  for (const section of sections) {
    const head = document.createElement('div');
    head.className = 'diff-section-head';
    head.textContent = section.path;
    els.diffList.append(head);

    if (section.kind === 'section-added') {
      const row = document.createElement('div');
      row.className = 'diff-entry added';
      row.textContent = '+ section added';
      els.diffList.append(row);
      continue;
    }
    if (section.kind === 'section-removed') {
      const row = document.createElement('div');
      row.className = 'diff-entry removed';
      row.textContent = '− section removed';
      els.diffList.append(row);
      continue;
    }

    for (const change of section.changes) {
      const row = document.createElement('div');
      if (change.kind === 'block-added') {
        row.className = 'diff-entry added';
        row.textContent = `+ ${describeBlock(change.block)}`;
      } else if (change.kind === 'block-removed') {
        row.className = 'diff-entry removed';
        row.textContent = `− ${describeBlock(change.block)}`;
      } else if (change.kind === 'list-changed') {
        for (const item of change.added) {
          const addRow = document.createElement('div');
          addRow.className = 'diff-entry added';
          addRow.textContent = `+ ${item}`;
          els.diffList.append(addRow);
        }
        for (const item of change.removed) {
          const removeRow = document.createElement('div');
          removeRow.className = 'diff-entry removed';
          removeRow.textContent = `− ${item}`;
          els.diffList.append(removeRow);
        }
        continue;
      } else if (change.words) {
        row.className = 'diff-entry changed';
        row.innerHTML = `~ ${change.blockType}: ${renderWords(change.words)}`;
      } else {
        row.className = 'diff-entry changed';
        row.innerHTML = `~ ${change.blockType}: <del>${change.before}</del> <ins>${change.after}</ins>`;
      }
      els.diffList.append(row);
    }
  }
  return { sections, summary, report: markdownDiffReport(sections) };
}

function renderSummary(summary) {
  const parts = [];
  if (summary.added) parts.push(`<span class="added">+${summary.added}</span>`);
  if (summary.removed) parts.push(`<span class="removed">−${summary.removed}</span>`);
  if (summary.changed) parts.push(`<span class="changed">~${summary.changed}</span>`);
  els.diffSummary.innerHTML = parts.join(' ');
}

function runCompare() {
  const textA = els.compareA.value;
  const textB = els.compareB.value;
  els.compareError.hidden = true;
  els.diffList.replaceChildren();
  els.diffSummary.innerHTML = '';
  els.compareDownload.disabled = true;
  lastReport = '';

  if (!textA.trim() && !textB.trim()) {
    els.diffEmpty.hidden = true;
    return;
  }

  if (state.format === 'json') {
    let valueA;
    let valueB;
    try {
      valueA = JSON.parse(textA || 'null');
    } catch (error) {
      els.compareError.textContent = `A: ${error.message}`;
      els.compareError.hidden = false;
      els.diffEmpty.hidden = true;
      return;
    }
    try {
      valueB = JSON.parse(textB || 'null');
    } catch (error) {
      els.compareError.textContent = `B: ${error.message}`;
      els.compareError.hidden = false;
      els.diffEmpty.hidden = true;
      return;
    }
    const { changes, summary, report } = renderJsonDiff(valueA, valueB);
    els.diffEmpty.hidden = changes.length > 0;
    renderSummary(summary);
    lastReport = report;
    els.compareDownload.disabled = false;
    return;
  }

  const { sections, summary, report } = renderMarkdownDiff(textA, textB);
  els.diffEmpty.hidden = sections.length > 0;
  renderSummary(summary);
  lastReport = report;
  els.compareDownload.disabled = false;
}

els.compareA.addEventListener('input', () => { state.compareA = els.compareA.value; runCompare(); save(); });
els.compareB.addEventListener('input', () => { state.compareB = els.compareB.value; runCompare(); save(); });

els.compareSwap.addEventListener('click', () => {
  const a = els.compareA.value;
  els.compareA.value = els.compareB.value;
  els.compareB.value = a;
  state.compareA = els.compareA.value;
  state.compareB = els.compareB.value;
  runCompare();
  save();
});

els.compareDownload.addEventListener('click', () => {
  if (!lastReport) return;
  downloadText(state.format === 'json' ? 'diff-report.txt' : 'diff-report.md', lastReport);
});

// ---- url ----

async function copyToClipboard(text, message) {
  if (!text) return;
  await navigator.clipboard.writeText(text);
  setStatus(message);
}

function renderUrlOutputs() {
  els.urlOriginal.value = urlParsed ? urlParsed.toString() : '';
  els.urlModified.value = urlParsed ? buildUrl(urlParsed, urlParams) : '';
  els.urlCopyOriginal.disabled = !els.urlOriginal.value;
  els.urlCopyModified.disabled = !els.urlModified.value;
}

// Rebuilds the rows from urlParams. Typing in a row updates urlParams in place and
// only refreshes the outputs, so the row keeps focus; add/delete re-render the list.
function renderUrlRows() {
  els.urlParamsEmpty.hidden = urlParams.length > 0;
  els.urlParamsList.replaceChildren();

  urlParams.forEach((param, index) => {
    const rowEl = els.urlParamTemplate.content.firstElementChild.cloneNode(true);
    const keyInput = rowEl.querySelector('.url-param-key');
    const valueInput = rowEl.querySelector('.url-param-value');
    keyInput.value = param.key;
    valueInput.value = param.value;
    keyInput.addEventListener('input', () => {
      urlParams[index].key = keyInput.value;
      renderUrlOutputs();
    });
    valueInput.addEventListener('input', () => {
      urlParams[index].value = valueInput.value;
      renderUrlOutputs();
    });
    rowEl.querySelector('.url-param-copy').addEventListener('click', () => {
      copyToClipboard(valueInput.value, `Copied "${keyInput.value || 'value'}" to the clipboard.`);
    });
    rowEl.querySelector('.url-param-delete').addEventListener('click', () => {
      urlParams = removeParam(urlParams, index);
      renderUrlRows();
      renderUrlOutputs();
    });
    els.urlParamsList.append(rowEl);
  });
}

function renderUrlParams() {
  const { url, error } = parseUrl(state.appliedUrl);
  els.urlError.textContent = error || '';
  els.urlError.hidden = !error;
  els.urlParamsField.hidden = !url;

  urlParsed = url;
  urlParams = paramsFromUrl(url);
  renderUrlRows();
  renderUrlOutputs();
}

els.urlAddParam.addEventListener('click', () => {
  urlParams = addParam(urlParams);
  renderUrlRows();
  renderUrlOutputs();
  els.urlParamsList.lastElementChild?.querySelector('.url-param-key').focus();
});

function updateUrlStale() {
  els.urlStale.hidden = els.urlInput.value.trim() === state.appliedUrl.trim();
}

// The params list only re-parses on Apply, so it never silently drifts from (or
// gets overwritten by) whatever is in the URL field.
function applyUrl() {
  state.appliedUrl = els.urlInput.value;
  renderUrlParams();
  updateUrlStale();
  save();
}

els.urlInput.addEventListener('input', () => {
  state.url = els.urlInput.value;
  updateUrlStale();
  save();
});
els.urlInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') applyUrl();
});
els.urlApply.addEventListener('click', applyUrl);

els.urlCopyOriginal.addEventListener('click', () => {
  copyToClipboard(els.urlOriginal.value, 'Copied the original URL to the clipboard.');
});

els.urlCopyModified.addEventListener('click', () => {
  copyToClipboard(els.urlModified.value, 'Copied the modified URL to the clipboard.');
});

// ---- startup ----

(async () => {
  const stored = await api.storage.local.get(STORAGE_KEY);
  state = { ...DEFAULT_STATE, ...(stored[STORAGE_KEY] || {}) };

  els.beautifyInput.value = state.beautifyInput;
  els.compareA.value = state.compareA;
  els.compareB.value = state.compareB;
  els.urlInput.value = state.url;

  activateTab(state.tab);
  activateFormat(state.format);
  activateIndent(state.indent);
  runBeautify();
  runCompare();
  renderUrlParams();
  updateUrlStale();
})();
