# Djaunt Prettifier

A Chrome & Firefox extension (Manifest V3) that beautifies JSON, renders Markdown in a live
two-panel editor, runs a structural comparison between two versions of either, and parses a
URL's query string into editable, copyable params you can add to and delete from — with no
host permissions at all.

It's built to replace pasting text into a random online "JSON diff" or "beautify" site: those
send whatever you paste to someone else's server, which is a bad habit for anything that might
contain a real API response, a config file, or an internal doc. Everything here runs in the
popup, on your machine, and nothing leaves it.

## Install

**Chrome:**

1. Open `chrome://extensions`.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and select this folder.
4. Pin the extension so the toolbar button is visible.

**Firefox** (121+, for this manifest's dual background key):

1. Open `about:debugging#/runtime/this-firefox`.
2. Click **Load Temporary Add-on…** and select this folder's `manifest.json`.

This load is temporary — Firefox drops it on restart, so reload it the same way after a
`git pull`. For a load that survives restarts, package the folder with
[`web-ext`](https://github.com/mozilla/web-ext) and sign it, or run it in a channel that
allows unsigned extensions (Nightly/ESR with `xpinstall.signatures.required` off in
`about:config`).

## Use

Click the toolbar icon and pick a tab:

- **Beautify.** Pick **JSON** or **Markdown**.
  - **JSON:** paste into Input; the formatted result appears in Result as you type, with a
    2- or 4-space indent (your choice). **Copy** or **Download** it.
  - **Markdown:** the popup widens into two panels — an editor on the left, a live rendered
    preview on the right. Paste or type and the preview updates on every keystroke. It renders
    full CommonMark plus GitHub-style tables, strikethrough, task lists (`- [x]`) and
    autolinks; headings get anchors, so `[jump](#some-heading)` links scroll the preview.
    The editor's buttons: **Tidy** rewrites the source in place (consistent heading spacing,
    a single bullet marker, renumbered ordered lists, normalized horizontal rules, collapsed
    blank lines — fenced code untouched; **Ctrl+Z** undoes it), **Copy** and **Download** the
    Markdown. **Copy rendered** on the preview copies the document as formatted text, so it
    pastes as real headings, lists and tables into email or a rich-text editor.
  - The preview is safe to paste untrusted text into: raw HTML in the source is shown as
    literal text, never executed; `javascript:` links are refused; and **images are not
    loaded** (a remote image would contact its server, which this extension doesn't do) —
    each shows as an `[image: alt]` link instead. Inline `data:image/…` images do render.
- **Compare.** Pick **JSON** or **Markdown**, paste the original into A and the changed
  version into B (or click the swap button to flip them). Differences appear live below:
  - **JSON** is diffed structurally, by parsed value, not by text — reordering an object's
    keys or reformatting its whitespace produces no diff at all. Each entry names the exact
    property path (`user.address.city`, `tags[2]`) and whether it was added, removed, changed,
    or changed type.
  - **Markdown** is diffed by document structure: headings group the document into sections,
    and each section's paragraphs, lists, quotes and code blocks are compared individually. An
    unchanged heading with one new bullet reads as "1 item added to this list," not as a
    rewritten paragraph; a changed sentence shows which words were added or removed, not just
    that the line differs.

  **Download report** saves the same differences as a plain-text file.
- **URL.** Paste a URL into the field at the top and click **Apply** (or press Enter) to load
  its query parameters into editable Name / Value rows below. The list only reloads on Apply,
  so your row edits are never overwritten by a stray keystroke in the URL field; a note appears
  whenever the field has changed since the last Apply. Edit a name or value, **Copy** just a row's value, delete a
  row with **✕**, or add a new one with **+ Add param** (a new row is ignored until you give
  it a name). The **Original** and **Modified** boxes below update live, each with its own
  **Copy** button so you can grab either the untouched or the edited URL. Clearing a value
  leaves an empty param (`key=`); to remove the param entirely, delete its row. The scheme,
  host, path and fragment are never touched — only the query string is rebuilt.

## How it works

- **`diff.js`** is a small longest-common-subsequence algorithm shared by both formats — the
  same primitive that finds the minimal add/remove set between two arrays, whether those
  arrays are object keys, Markdown blocks, list items, or words in a sentence.
- **`json-tool.js`** parses and re-serializes with `JSON.parse`/`JSON.stringify`, and walks two
  parsed values recursively to build the structural diff (`diffJson`). A parse error is
  reported with the line and column it occurred at, when the engine's own error message
  provides one.
- **`markdown-render.js`** wraps the vendored **[markdown-it](https://github.com/markdown-it/markdown-it)**
  parser (`vendor/`, MIT — its licence sits beside it) with the safety settings above, heading
  ids, task-list checkboxes, new-tab links and scrollable tables. The manifest's CSP also sets
  `img-src 'self' data:`, so even a rendering bug couldn't fetch a remote image.
- **`markdown-tool.js`** parses Markdown into typed blocks (heading, paragraph, list, code
  fence, blockquote, horizontal rule) with `parseMarkdownBlocks`, groups them under their
  nearest heading with `groupSections`, and diffs matching sections' blocks with `diffMarkdown`
  — including a word-level diff for changed paragraphs and an item-level diff for changed
  lists, both built on `diff.js`.
- **`url-tool.js`** parses a pasted string with the standard `URL` constructor (`parseUrl`),
  reads its query string into an ordered param list via `URLSearchParams` (`paramsFromUrl`,
  keeping duplicate keys as separate rows), adds/removes rows (`addParam`, `removeParam`), and rebuilds just the query string from an edited
  param list while leaving the origin, path and hash untouched (`buildUrl`).
- **Nothing is sent anywhere.** The manifest requests only `storage` (to remember what you last
  typed between popup opens) — no `host_permissions`, no content script, no network call.
  Download uses a `Blob` URL and an anchor's `download` attribute, not the `downloads` API.

## Limits

- **The Compare tab is a heuristic comparator, not a renderer** (Beautify → Markdown is the
  renderer). It understands ATX headings
  (`#`/`##`), bullet and numbered lists, fenced code, blockquotes, horizontal rules and
  paragraphs — not tables, nested lists, footnotes, or inline HTML. Anything else is treated as
  a plain paragraph.
- **Section matching is by heading text**, and a renamed heading is detected as a rename only
  when it sits at the same depth under the same parent as before; anything more drastic (a
  section moved to a different parent, or two unrelated same-depth sections swapping position)
  shows as a remove and an add instead.
- **List-item and paragraph matching is by content, not position** — reordering a list's items
  or a document's paragraphs can show fewer changes than you'd expect from a plain text diff,
  since the comparator is finding the smallest edit that explains the difference, not comparing
  line-by-line.
- **The preview doesn't render footnotes, definition lists, math, diagrams, or raw HTML**
  (HTML is shown as text on purpose), and code blocks aren't syntax-highlighted.
- Very large inputs (many thousands of lines) will diff slowly — the LCS algorithm is
  quadratic in the number of compared items. It's sized for pasting a response body or a
  document, not a whole repository.

## Permissions

`storage` only. No `host_permissions`, no `<all_urls>`, no content scripts, no background
script — the whole extension runs inside the popup. The manifest also pins the extension-page
CSP to `script-src 'self'; object-src 'self'; img-src 'self' data:`.

## Tests

`test.mjs` covers `diff.js`, `json-tool.js`, `markdown-tool.js`, `markdown-render.js` and
`url-tool.js`: LCS
behavior, JSON beautify/minify/parse-error reporting, structural JSON diffing, Markdown block
parsing, beautification, sectioning, the section/list/paragraph-level Markdown diff, Markdown rendering
(including that raw HTML, `javascript:` links and remote images never reach the preview as
markup), and URL parsing, duplicate-key handling, adding/removing params, and query-string rebuilding.

```
node test.mjs
```

No test runner needed — it exits non-zero on failure.
